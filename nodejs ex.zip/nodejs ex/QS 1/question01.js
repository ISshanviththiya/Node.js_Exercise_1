var http = require('http');
var as = require('./as.js');

http.createServer(function (req, res) {
    res.writeHead(200, {'Content-Type': 'text/html'});
    res.write(`Sum Number =  ${as.sumNum(123, 321)}` );<br>
    res.write(`Average Number = ${as.average(123, 321)}` );
    res.end();
}).listen(8080);
