exports.sumNum =function (a, b){
    return a + b ;
}

exports.average =function (a, b){
    return (a + b)/2;
}
